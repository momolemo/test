SASS files are optional! They are not required to start working with MDB.

You don't need to include them in your project.